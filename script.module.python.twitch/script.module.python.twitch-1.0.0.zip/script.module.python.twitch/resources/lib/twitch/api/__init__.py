# -*- encoding: utf-8 -*-

from twitch.api import v5
from twitch.api import v5 as default

__all__ = ['v5', 'default']
